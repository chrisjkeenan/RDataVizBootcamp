#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTRO TO R PART5 ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#=================================================-
#### Slide 7: Installing packages  ####

install.packages("tidyverse")   #<- Install package 
library(tidyverse)              #<- Load the package into the environment.
library(help = "tidyverse")     #<- View package documentation.


#=================================================-
#### Slide 8: Directory settings  ####

# Set `main_dir` to the location of your `skillsoft-2021` folder (for Mac/Linux).
main_dir = "~/Desktop/skillsoft-2021"
# Set `main_dir` to the location of your `skillsoft-2021` folder (for Windows).
main_dir = "C:/Users/[username]/Desktop/skillsoft-2021"

# Make `data_dir` from the `main_dir` and remainder of the path to data directory.
data_dir = paste0(main_dir, "/data")
# Make `plots_dir` from the `main_dir` and remainder of the path to plots directory.
plot_dir = paste0(main_dir, "/plots")

# Set directory to data_dir.
setwd(data_dir)


#=================================================-
#### Slide 10: Installing packages and loading data  ####

#install.packages("nycflights13")
library(nycflights13)


#=================================================-
#### Slide 12: A little more about tidyverse  ####

tidyverse_update()


#=================================================-
#### Slide 14: Data transformation  ####

# Load the dataset and save it as 'flights' 
# It is native to r so we can load it like this
flights = nycflights13::flights	

?flights


#=================================================-
#### Slide 18: Filter   ####

# Check for detailed documentation
?dplyr::filter

# Use cases for `filter` function

filter(df,           #<- dataframe 
       filter_cond1, #<- subsetting rule(s)   
       ...)          #<- other arguments


#=================================================-
#### Slide 19: Filter   ####

# Load the flights dataset into the environment.
data(flights)

# Filter `flights` data frame to display all records from January (month == 1) of 2013 (year == 2013).
filter(flights,      #<- set data 
       month == 1,   #<- filter by month 
       year == 2013) #<- filter by year


#=================================================-
#### Slide 20: Filter   ####

# You will have to make sure to save the subset. To do this, use `=`.
filter_flights = filter(flights, month == 1, year == 2013)

# View your output.
filter_flights


#=================================================-
#### Slide 23: Filter - examples of logical operators  ####

# Filter with just `&`.
filter(flights, month == 1 & day == 25)


#=================================================-
#### Slide 24: Filter - examples of logical operators (cont...)  ####

# Filter with `!`.
filter(flights, month != 1 & day != 25)


#=================================================-
#### Slide 25: Filter - examples of logical operators (cont...)  ####

# Filter with `%in%`.
filter(flights, month %in% c(1, 2) & day == 25)


#=================================================-
#### Slide 26: Using filter with NA values  ####

# Create a data frame with 2 columns.
NA_df = data.frame(x = c(1, NA, 2),  #<- column x with 3 entries with 1 NA
                   y = c(1, 2, 3))   #<- column y with 3 entries

# Filter without specifying anything regarding NAs.
filter(NA_df, x >= 1)

# Filter with specifying to keep rows if there is an NA.
filter(NA_df, is.na(x) | x >= 1)


#=================================================-
#### Slide 29: Arrange  ####

# Check for detailed documentation
?dplyr::arrange

# Use cases for `arrange` function
arrange(df,            #<- data frame 
        arrange_cond1, #<- column by which 
                       #   to arrange
        ...)           #<- other args.


#=================================================-
#### Slide 30: Arrange example  ####

# Arrange data by year, then month, and then day.
arrange(flights, #<- data frame we want to arrange
        year,    #<- 1st: arrange by year
        month,   #<- 2nd: arrange by month 
        day)     #<- 3rd: arrange by day


#=================================================-
#### Slide 31: Arrange options  ####

# Arrange data by year, descending month and then day.
arrange(flights,     #<- data frame we want to arrange
        year,        #<- 1st: arrange by year
        desc(month), #<- 2nd: arrange by month in descending order
        day)         #<- 3rd: arrange by day 


#=================================================-
#### Slide 32: Arrange with NA values  ####

# Arrange data with missing values.
arrange(NA_df, x)

# Even when we use `desc` the `NA` is taken to the last row.
arrange(NA_df, desc(x))



#=================================================-
#### Slide 33: Exercise 1  ####




#=================================================-
#### Slide 35: Select  ####

# Check for detailed documentation
?dplyr::select

# Use cases for `select` function
select(df,           #<- dataframe 
       select_cond1, #<- selection rule(s)
       ...)


#=================================================-
#### Slide 36: Select a subset  ####

# Select columns from `flights` data frame.
select(flights, #<- specify the data frame
       year,    #<- specify the 1st column
       month,   #<- specify the 2nd column
       day)     #<- specify the 3rd column
# Select columns from `flights` data frame
select(flights,  #<- specify the data frame
       year:day) #<- specify the range of columns


#=================================================-
#### Slide 37: Select by excluding  ####

# Select multiple columns from `flights` data frame by providing which columns to exclude in selection
select(flights,     #<- specify the data frame
       -(year:day)) #<- specify the range of columns to exclude


#=================================================-
#### Slide 38: Select - helper functions  ####

select(flights, starts_with("arr"))


#=================================================-
#### Slide 39: Mutate  ####

?dplyr::mutate

mutate(df,       # <- dataframe 
       new_col1, # <- rule(s) for the new column
       ...)


#=================================================-
#### Slide 40: Mutate - create the dataset  ####

# Let's select columns of `flights` data frame and save them as `flights_sml`.
flights_sml = select(flights,            #<- specify data fra,e
                     year:day,           #<- specify range of columns to include
                     ends_with("delay"), #<- find all columns that end with `delay`
                     distance,           #<- select `distance` column
                     air_time)           #<- select `air_time` column
flights_sml


#=================================================-
#### Slide 41: Mutate - arguments  ####

# Add two columns `gain` and `speed` to `flights_sml`. 
mutate(flights_sml,                      #<- specify the data frame
       gain = arr_delay - dep_delay,     #<- create `gain` column by subtracting departure delay 
                                         #   from arrival delay
       speed = distance / air_time * 60) #<- create `speed` from distance and air time columns


#=================================================-
#### Slide 42: Transmute  ####

transmute(df,       # <- dataframe 
          new_col1, # <- rule(s) for new column
          ...) 


#=================================================-
#### Slide 43: Transmute example  ####

# Add two columns `gain` and `speed` to `flights_sml`. 
transmute(flights_sml,                      #<- specify the data frame
          gain = arr_delay - dep_delay,     #<- create `gain` column by subtracting departure delay 
                                            #   from arrival delay
          speed = distance / air_time * 60) #<- create `speed` from distance and air time columns


#=================================================-
#### Slide 45: Mutate and transmute - useful functions (cont...)  ####

# Check for detailed documentation
?dplyr::ranking

rank_function(x) # <- one of rank functions with
                 #    a vector of values to rank  


#=================================================-
#### Slide 47: Exercise 2  ####




#######################################################
####  CONGRATULATIONS ON COMPLETING THIS MODULE!   ####
#######################################################
