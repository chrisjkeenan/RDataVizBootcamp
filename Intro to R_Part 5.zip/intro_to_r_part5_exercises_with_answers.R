#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTRO TO R PART5 EXERCISE ANSWERS ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#### Exercise 1 ####
# =================================================-

#### Question 1 ####
# Load the `tidyverse` package. (Install if you don't have it already)
# Install and load `babynames` package.
# (this dataset is native to R)
# Filter all values in `babynames` that year is 2015.

# Answer:
library(tidyverse)
install.packages("babynames")
library(babynames)
filter(babynames, year == 2015)

#================================================-
#### Question 2 ####
# Filter all values in babynames that year is 2015 and sex is F.

# Answer:
filter(babynames,year == 2015,sex == 'F')

#================================================-
#### Question 3 ####
#Filter all values that are below 1000 counts (`n`) and that are between 1947-1975.

# Answer:
filter(babynames, n < 1000, year >= 1947, year <= 1975)

#================================================-
#### Question 4 ####
# Filter all values that are either sex is F or n is above 1000 counts, all in 1975.

# Answer:
filter(babynames, year == 1975, (sex == 'F' | n > 1000))


#### Question 5 #### 
# Arrange `babynames` by year in descending order.

# Answer:
arrange(babynames, desc(year))

#================================================-
#### Question 6 ####
# Now arrange by year then by sex. What are the name and year in row 1?

# Answer: Name: Mary, Year: 1880
arrange(babynames, year, sex)

#================================================-
#### Question 7 ####
# Now arrange by sex, year, and name descending. What is the name in the first row?

# Answer: Zula
arrange(babynames, sex, year, desc(name))



#### Exercise 2 ####
# =================================================-

#### Question 1 ####
# Select only year,name and count (`n`) from `babynames`.

# Answer:
select(babynames, year, name, n)

#================================================-
#### Question 2 ####
# Now select the same columns, but by specifying which NOT to include in the subset.

# Answer:
select(babynames, -c(sex, prop))

#================================================-
#### Question 3 #### 
# Use the helper functions of `select` to find all columns that contain the letter `e`.

# Answer:
select(babynames,contains("e"))


##### Question 4 ####
# Subset `babynames` to be all names from 2015, keep all columns, save the subset as babynames_small.
# Using the newly created subset and `mutate`, create a new column "rank" that ranks by the count (`n`). Save the new subset as `babynames_mutate`.

# Answer:
babynames_small = filter(babynames, year == 2015)
babynames_mutate = mutate(babynames_small,rank = dense_rank(n))
babynames_mutate

#================================================-
#### Question 5 ####
# Arrange the mutated dataset by rank descending, then by name. What is the rank,name and sex in the first row?

# Answer: 1386, Emma, F
arrange(babynames_mutate,desc(rank),name)

#================================================-
#### Question 6 ####
# Now instead of the `babynames_mutate` subset, use a function that will simply create one column that gives you the rank of the counts - "RANK". Use the dataset `babynames_small`.

# Answer:
transmute(babynames_small,RANK = dense_rank(n))



