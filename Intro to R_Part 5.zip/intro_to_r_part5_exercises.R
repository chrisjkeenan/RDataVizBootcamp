#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTRO TO R PART5 EXERCISE ANSWERS ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#### Exercise 1 ####
# =================================================-

#### Question 1 ####
# Load the `tidyverse` package. (Install if you don't have it already)
# Install and load `babynames` package.
# (this dataset is native to R)
# Filter all values in `babynames` that year is 2015.

# Answer:


#================================================-
#### Question 2 ####
# Filter all values in babynames that year is 2015 and sex is F.

# Answer:


#================================================-
#### Question 3 ####
#Filter all values that are below 1000 counts (`n`) and that are between 1947-1975.

# Answer:



#================================================-
#### Question 4 ####
# Filter all values that are either sex is F or n is above 1000 counts, all in 1975.

# Answer:


#================================================-
#### Question 5 #### 
# Arrange `babynames` by year in descending order.

# Answer:



#================================================-
#### Question 6 ####
# Now arrange by year then by sex. What are the name and year in row 1?

# Answer: 



#================================================-
#### Question 7 ####
# Now arrange by sex, year, and name descending. What is the name in the first row?

# Answer: 




#### Exercise 2 ####
# =================================================-

#### Question 1 ####
# Select only year,name and count (`n`) from `babynames`.

# Answer:


#================================================-
#### Question 2 ####
# Now select the same columns, but by specifying which NOT to include in the subset.

# Answer:


#================================================-
#### Question 3 #### 
# Use the helper functions of `select` to find all columns that contain the letter `e`.

# Answer:


#================================================-
##### Question 4 ####
# Subset `babynames` to be all names from 2015, keep all columns, save the subset as babynames_small.
# Using the newly created subset and `mutate`, create a new column "rank" that ranks by the count (`n`). Save the new subset as `babynames_mutate`.

# Answer:


#================================================-
#### Question 5 ####
# Arrange the mutated dataset by rank descending, then by name. What is the rank,name and sex in the first row?

# Answer: 


#================================================-
#### Question 6 ####
# Now instead of the `babynames_mutate` subset, use a function that will simply create one column that gives you the rank of the counts - "RANK". Use the dataset `babynames_small`.

# Answer:



