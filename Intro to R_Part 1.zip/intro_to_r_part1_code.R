#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTRO TO R PART1 ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#=================================================-
#### Slide 16: Working with R: comments  ####

# This is a typical comment in R.
# You don't need a hashmark at 
# the end of the line.
# You can add as many as you want,
# just be sure to read them afterwards :)

A = 2 + 5 #<- you can also add comments
B = A + 3 #<- to the end of the code lines


#=================================================-
#### Slide 18: Basic calculations and operations  ####

# Add whole numbers.
1 + 2

# Add numbers with decimals.
3.23 + 4.65
# Subtract whole numbers.
10 - 7

# Subtract numbers with decimals.
3.23 - 4.65


#=================================================-
#### Slide 19: Basic calculations and operations  ####

# Multiply whole numbers.
1 * 2

# Multiply numbers with decimals.
3.23 * 4.65
# Divide whole numbers.
9 / 3

# Divide numbers with decimals.
3.23 / 4.65


#=================================================-
#### Slide 20: Basic calculations and operations  ####

# Take square root of a number with.
sqrt(100)

# Take square root of an expression.
sqrt(7 * 5)
# Raise number to a power with `^`.
9 ^ 3

# Raise number to a power with `**`.
9 ** 3

# Raise expression to a power.
(3.23 / 4.65)^2


#=================================================-
#### Slide 21: Basic calculations and operations  ####

# Get remainder from division.
7 %% 3

# Get remainder from division.
4 %% 2
# Perform integer division.
7 %/% 3

# Perform integer division.
4 %/% 2


#=================================================-
#### Slide 22: Variables and assignment operators  ####

# Define a variable using `<-` 
# as an assignment operator.
A <- 3  
A

# Define a variable using `=` 
# as an assignment operator.
B = 2 + 5
B


#=================================================-
#### Slide 23: Operations with variables  ####

# Add 2 variables.
C = A + B
C

# Add a variable and a number.
D = C + 5
D
# Subtract 2 variables from each other.
D - C

# Subtract a variable from number.
33 - D

# Or a number from a variable.
D - 33


#=================================================-
#### Slide 24: Other operators: comparison  ####

# Check variables are equal.
A == B

# Check if variables are not equal.
A != B

# Check if one is greater than the other.
A > B
# Check if one is greater than or equal to 5.
A >= 5

# Check if one is less than or equal to 3.
A <= 3

# Check if one is smaller than the other.
A < B


#=================================================-
#### Slide 26: Grouping multiple operations with variables  ####

# You can group several operations into
# a single one.
((D - C) * 2) ^ (1 / 3)
# This is equivalent to a series of steps 
# like ones below.
step1 = D - C
step1

step2 = step1 * 2
step2

step3 = 1 / 3
step3

step4 = step2 ^ step3
step4


#=================================================-
#### Slide 27: Grouping multiple operations with variables  ####

# You can group several operations into a single one.
((D - C) * 2) ^ (1 / 3)

# Be careful with your operators and your parentheses, the following expression 
# will not return the same result as the one above!
((D - C) * 2) ^ 1 / 3


#=================================================-
#### Slide 29: Variable value re-assignment  ####

# 1. Create a variable and assign 67 to it.
this_variable = 67
this_variable

# 2. Create another variable and assign -54.
that_variable = -54
that_variable

# 3. Calculate their sum.
this_variable + that_variable
# 4. Re-assign a value to `this_variable`.
this_variable = 35
this_variable

# 5. Add two variables and store the result 
#    in `that_variable`.
that_variable = this_variable + that_variable
that_variable


#=================================================-
#### Slide 31: Exercise 1  ####




#######################################################
####  CONGRATULATIONS ON COMPLETING THIS MODULE!   ####
#######################################################
