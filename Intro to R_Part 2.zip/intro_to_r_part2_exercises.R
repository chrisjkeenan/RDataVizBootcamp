#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTRO TO R PART2 EXERCISE ANSWERS ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#### Exercise 1 ####
# =================================================-


#================================================
#### Question 1 ####

# Make a variable called `007Agent` and assign this character string to it: "Bond, James Bond".
007Agent = "Bond, James Bond"

# Answer: 


#================================================
#### Question 2 ####

# Create a logical variable named `logvar` and assign it the value FALSE.
# Confirm the type of variable for logvar.
# Then convert the logical variable to a character variable named `new_char2`.
# Check the value of the new variable in the Global Environment. 
# Then confirm the class of the new variable.

# Answer: 


#================================================-
#### Question 3 ####

test = 234.3

# What is the class of the `test` variable?
# What is the type of the `test` variable?
# Convert `test` to an `integer` and assign it to variable `test2`.
# Then confirm the new class of `test2`.

# Answer: 


#================================================-
#### Question 4 ####

# Create a numeric vector named `numvec` that contains the values 2.3, 4, 5.63, and 4.623.
# Return the values of `numvec`.
# Convert the vector `numvec` to a vector of integers named `intvec`.
# Then confirm if the vector contains integers or not. 
# The answer should be either TRUE or FALSE.

# Answer:


#================================================-
#### Question 5 ####

# Check how many items are in `intvec`.
# Then append the values 7, 14, and 8 to the vector `intvec`.
# Check the length of intvec again. What changed?

# Answer: 


#================================================-
#### Question 6 ####

# Add the value 3 to all values in `intvec` and assign it back to the variable 'intvec'

# Answer:


#================================================-
#### Question 7 ####

# Create another vector named `seqvec` that starts at 2, ends at 14, and the numbers increase by 2.
# What is the length of `seqvec`?
# Assign the result of subtracting `intvec` from `seqvec` to the vector `resvec`. 

# Answer: 


#================================================-
#### Question 8 ####

# What is the product of resvec?
# What is the minimum value in resvec?
# What is the mean of resvec?

# Answer: 


#================================================-
#### Question 9 ####

# Bind the vectors `intvec`, `seqvec`, and `resvec` together as columns to create `matrix_c`.
# Separately bind the vectors together as rows to create `matrix_r`.
# Confirm the class of both `matrix_c` and` matrix_r`.
# How many rows and columns are there in `matrix_c` and `matrix_r` ?

# Answer: 



#================================================-
#### Question 10 ####

# Check the type of matrix (hint: is it numeric, character, integer?)

# Answer:



#================================================-
#### Question 11 ####

# Check the attributes of `matrix_c`. 
# Which dimension of `matrix_c` has names? Rows or columns?
# Rename the columns in `matrix_c` to be "var1", "var2", and "var3".

# Answer: 



#================================================-
#### Question 12 ####

# Return a matrix that is a 2x2 subset of `matrix_c` starting at the upper left corner of `matrix_c`.
# Name this new matrix `mat_sub`.
# Confirm the class of `mat_sub`.
# What is the average value of `mat_sub`?

# Answer: 

